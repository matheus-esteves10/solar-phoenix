package br.com.fiap.dto;

public record LoginDto (String login,
                       String senha) {
}
