package br.com.fiap.exceptions;

public class NotFoundException extends Exception {

}
