package br.com.fiap.exceptions;

public class UnsupportedServiceOperationException extends Exception{
}
