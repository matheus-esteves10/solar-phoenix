package br.com.fiap.exceptions;

public class NotSavedException extends Exception{
}
